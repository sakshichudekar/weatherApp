package com.example.weatherapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {

    private TextView cityNameText, temperatureText, decriptionText, windValueText, humidityValueText;
    private ImageView weatherIcon;
    private Button refreshButton;
    private EditText cityNameInput;
    private static final String API_KEY = "54f2cf638a3ec5ae420a5c636fa7631d";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cityNameText = findViewById(R.id.cityNameText);
        temperatureText = findViewById(R.id.temperatureText);
        decriptionText = findViewById(R.id.decriptionText);
        windValueText = findViewById(R.id.windValueText);
        humidityValueText = findViewById(R.id.humidityValueText);
        weatherIcon = findViewById(R.id.weatherIcon);
        refreshButton = findViewById(R.id.fetchWeatherButton);
        cityNameInput = findViewById(R.id.cityNameInput);

        refreshButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String cityName = cityNameInput.getText().toString().trim();
                if (!cityName.isEmpty()) {
                    FetchWeatherData(cityName);
                } else {
                    cityNameInput.setError("Please enter a city name");
                }
            }
        });

        // Default city
        FetchWeatherData("mumbai");
    }

    private void FetchWeatherData(String cityName) {
        String url = "https://api.openweathermap.org/data/2.5/weather?q=" + cityName + "&appid=" + API_KEY + "&units=metric";
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        executorService.execute(() -> {
            OkHttpClient client = new OkHttpClient();
            Request request = new Request.Builder().url(url).build();
            try {
                Response response = client.newCall(request).execute();
                if (response.isSuccessful() && response.body() != null) {
                    String result = response.body().string();
                    runOnUiThread(() -> updateUI(result));
                } else {
                    runOnUiThread(() -> cityNameText.setText("Failed to get data"));
                }
            } catch (IOException e) {
                e.printStackTrace();
                runOnUiThread(() -> cityNameText.setText("Error: " + e.getMessage()));
            }
        });
    }

    private void updateUI(String jsonResult) {
        try {
            JSONObject jsonObject = new JSONObject(jsonResult);
            JSONObject main = jsonObject.getJSONObject("main");
            double temperature = main.getDouble("temp");
            double humidity = main.getDouble("humidity");
            double windspeed = jsonObject.getJSONObject("wind").getDouble("speed");

            String description = jsonObject.getJSONArray("weather").getJSONObject(0).getString("description");
            String iconCode = jsonObject.getJSONArray("weather").getJSONObject(0).getString("icon");
            String resourceName = "ic_" + iconCode;
            int resId = getResources().getIdentifier(resourceName, "drawable", getPackageName());
            if (resId != 0) {
                weatherIcon.setImageResource(resId);
            }

            cityNameText.setText(jsonObject.getString("name"));
            temperatureText.setText(String.format("%.0f°", temperature));
            humidityValueText.setText(String.format("%.0f%%", humidity)); // fixed: removed ° before %
            windValueText.setText(String.format("%.0f km/h", windspeed));
            decriptionText.setText(description);

        } catch (JSONException e) {
            e.printStackTrace();
            cityNameText.setText("JSON Parsing Error");
        }
    }
}
